/**
 * 
 */
/**
 * 
 */
module SilkRoad {
	exports tests;
	requires java.desktop;
	requires org.junit.jupiter.api;
	requires junit;
}